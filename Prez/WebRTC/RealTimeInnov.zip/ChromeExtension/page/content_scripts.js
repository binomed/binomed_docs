var port = chrome.runtime.connect({name:'content_script'});

var peerConnection = null;
var sourcePeer = "";

/*
* MESSAGE FROM WEB PAGE !
*/

window.addEventListener("message", function(event) {
  // We only accept messages from ourselves
  if (event.source != window)
    return;

	switch(event.data.type){
		case "ASK_DESKTOP":
		case "ASK_TABS":
    		port.postMessage(event.data);
		break;		
	}
  
}, false);

chrome.runtime.onConnect.addListener(function (channel) {
    console.info('Register a new Channel ! '+channel.name+".");
});

/*
* MESSAGE FROM Background
*/

/*portTab.onMessage.addListener(function(msg){
	console.info('Message From portTab');
	console.info(msg);
});*/

//var newPort = chrome.runtime.connect({name:'test'});
port.onMessage.addListener(function(msg){
	console.info('Message From LongLivedConnection');
	console.info(msg);
	switch(msg.type){
	case 'selectTab' :
		console.log('Tab selected : '+msg.tabId);
		/*chrome.tabs.getSelected(null, function(tab) {
                var selectedTabId = tab.id;
                chrome.tabCapture.capture({
                    audio:true, 
                    video:true,
                    videoConstraints: {
                        mandatory: {
                            chromeMediaSource: 'tab',
                            minWidth: 1920,
                            maxWidth: 1920,
                            minHeight: 1080,
                            maxHeight: 1080
                        }
                    }
                }, gotStream); // bingo!
            });
		/*chrome.tabs.getSelected(null, function(tab) {
			var selectedTabId = tab.id;
			chrome.tabCapture.capture({audio:true, video:true}, gotStream); // bingo!
		});*/
		//chrome.tabCapture.capture({tabid : msg.tabId,audio:true, video:true}, gotStream); // bingo!
		//chrome.tabCapture.capture({tabid : msg.tabId,audio:true, video:true}, gotStream); // bingo!
		break;
	case 'gotScreen' :
		try{

			gotStream(msg.streamData);
		}catch(e){
			console.error(e);
		}

		try{
			document.querySelector("#video2").src  =msg.streamUrl;
		}catch(e){
			console.error(e);
		}
		/*navigator.webkitGetUserMedia({
		      audio:false,
		      video: { mandatory: { chromeMediaSource: "desktop",
		                            chromeMediaSourceId: msg.sourceId } }
		  }, gotStream, getUserMediaError);*/
		break;
	case 'gotScreenError' : 
		getUserMediaError();
		break;
	case 'call':
		sourcePeer = msg.peerId;		
		var server = null;
		peerConnection = new webkitRTCPeerConnection(server); 
		peerConnection.onicecandidate = function(event){
			if (event.candidate) {
				port.postMessage({peerId : sourcePeer, type:'candidate', candidate : event.candidate});			    
			}
		};
		peerConnection.onaddstream = gotStream;
		port.postMessage({peerId : sourcePeer, type:'continue'});			   
		break;
	case 'candidate':
        peerConnection.addIceCandidate(new RTCIceCandidate(msg.candidate));
        break;
    case 'description':
        peerConnection.setRemoteDescription(new RTCSessionDescription(msg.description));
        peerConnection.createAnswer(function(desc){
        	peerConnection.setLocalDescription(desc);
        	port.postMessage({peerId : sourcePeer, type:'description', description : desc});			    
        });
        break;
	}
});

function gotStream(stream) {
  console.log("Received local stream");
  var video = document.querySelector("#video");
  var url = URL.createObjectURL(stream.stream);
  video.src = url;
  localstream = stream.stream;
  stream.onended = function() { console.log("Ended"); };
}

function getUserMediaError(e) {
  console.log("getUserMedia() failed.");
  console.error(e);
}

/*
chrome.runtime.onConnect.addListener(function(_port) {
	console.info('Connect ContentScript');
	port = _port;
	console.info(_port);
	  _port.onMessage.addListener(function(msg) {
	  	console.info(msg);
	  	if (msg.type === "CALLBACK"){
	  		window.postMessage({ type: "CALLBACK", text: msg.text }, "*");
	  	}
	    //_port.postMessage({counter: msg.counter+1});
	  });
	});
	
	chrome.extension.onRequest.addListener(
	  function(request, sender, sendResponse) {
	  	console.info(request);
	    //sendResponse({counter: request.counter+1});
	  });

	console.info('test');*/