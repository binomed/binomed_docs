'use strict';

var content = document.getElementById("main-content");

var port = chrome.runtime.connect({name:'testtest'});
port.onMessage.addListener(function(msg){
	console.info(msg);
});

// The ID of the extension we want to talk to.
var editorExtensionId = "gamfjenlekhdioakijllochdnffmclhb";

window.addEventListener('message', function(event){
	if (event.source != window){
		return;
	}

	if (event.data.type && event.data.type == 'CALLBACK'){
		console.info('Callback from extension : ');
		console.info(event.data);
	}
});


var source = 'desktop';

document.querySelector('#source').addEventListener('change', function(e){
  source = e.target.value;
});

document.querySelector('#start').addEventListener('click', function(e) {  
  if (source == 'desktop'){
  	window.postMessage({ type: "ASK_DESKTOP"}, "*");
  }else if (source == 'tabs'){
  	window.postMessage({ type: "ASK_TABS"}, "*");
  }else if (source == 'camera'){
  	navigator.webkitGetUserMedia({
      audio:false,
      video: true
      }, gotStream, getUserMediaError);

  }


});

document.querySelector('#cancel').addEventListener('click', function(e) {
  if (pending_request_id != null) {
    chrome.desktopCapture.cancelChooseDesktopMedia(pending_request_id);
  }
});



function gotStream(stream) {
  console.log("Received local stream");
  var video = document.querySelector("#video");
  var url = URL.createObjectURL(stream);
  video.src = url;
  localstream = stream;
  stream.onended = function() { console.log("Ended"); };
}

function getUserMediaError(e) {
  console.log("getUserMedia() failed.");
  console.error(e);
}
